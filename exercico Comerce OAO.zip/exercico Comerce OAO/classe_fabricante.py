
class Fabricante:
    def __init__(self, cod, nome):
        self.cod = cod
        self.nome = nome

