from classe_banco_De_Dados import *


class Menu:

        banco_dados_mauro = Banco()

        # Iniciar menu
        while True:
            op = input('\n-=-=-=--=-= Informe a opção desejada -=-=-=--=-=\n1 | Cadastros\n2 | Listar Produtos\n3 | Alterar Nome Produto\n4 | Comprar produtos\n5 | Vender produtos\n6 | Historicos\n0 | Sair\n-=-= Sua Escolha: ').strip()

            if op == '1':# OPÇÃO PARA CADASTRAR NOVOS PRODUTOS
                while True:
                    op_cadastro = str(input('\n-=-=-=--=-= Cadastros -=-=-=--=-=\n1 | Cadastrar Fabricantes\n2 | Cadastrar Produtos\n0 | Voltar\n-=-= Sua Escolha: ')).strip()
                    if op_cadastro == '1':
                        cod = None
                        nome = str(input('Digite o nome do fabricante: ')).strip()
                        banco_dados_mauro.cadastrar_fabricante(cod, nome)

                    elif op_cadastro == '2':
                        quantidade = int(0)
                        cod = None
                        produto_nome = input('Digite o nome do Produto: ').strip()
                        produto_fabricante = input('Digite o nome do fabricante do Produto: ').strip()
                        produto_quantidade = quantidade
                        banco_dados_mauro.cadastrar_produto(cod, produto_nome, produto_fabricante, produto_quantidade)
                    elif op_cadastro == '0':
                        break

            elif op == '2':# OPÇÃO PARA LISTAR PRODUTOS
                cod_p = str(input('Digite o Codigo do produto que deseja filtrar / Clique "enter" para exibir todas: ')).strip()
                banco_dados_mauro.listar_produtos(cod_p)

            elif op == '3':# OPÇÃO PARA ALTERAR A DESCRIÇÃO DE UM PRODUTO
                cod = input('Entre com o COD do produto que será alterado: ')
                valor = str(input('Digite o novo nome para o Produto: ')).strip()
                atributo = 'nome_produto'
                banco_dados_mauro.alterar_dados(atributo, valor, cod)

            elif op == '4':# OPÇÃO PARA COMPRAS PRODUTOS
                cod = input('Entre com o COD do produto para efetuar a compra: ')
                quantidade_compra = int(input('Número de produtos que seram comprados: '))
                quantidade_final = quantidade_compra
                atributo = 'quantidade_produto'
                banco_dados_mauro.comprar_produtos(atributo, cod, quantidade_final)

            elif op == '5':# OPÇÃO PARA VENDER PRODUTOS
                cod = input('Entre com o COD do produto para efetuar a venda: ')
                quantidade_compra = int(input('Número de produtos que seram vendidos: '))
                quantidade_final = quantidade_compra
                atributo = 'quantidade_produto'
                banco_dados_mauro.vender_produtos(atributo, cod,  quantidade_final)

            elif op == '6':
                while True:
                    op_historico = str(input('\n-=-=-=--=-= Historicos -=-=-=--=-=\n1 | Historico Compras\n2 | Historico Vendas\n0 | Voltar\n-=-= Sua Escolha: ')).strip()
                    if op_historico == '1':
                        banco_dados_mauro.listar_historico_compra()
                    elif op_historico == '2':
                        banco_dados_mauro.listar_historico_venda()
                    elif op_historico == '0':
                        break
            elif op == '0':
                print('-=-=-=-=- Agradecemos por utlizar nosso sistema -=-=-=-=-')
                break
            else:
                print('Entrada incorreta')