class Produto:
    def __init__(self, cod, nome, fabricante, quantidade:0):
        self.cod = cod
        self.nome = nome
        self.fabricante = fabricante
        self.quantidade = quantidade

