from classe_menu import Menu

menu_produtos = Menu()